document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault();
    var username = document.getElementById('username').value;
    var password = document.getElementById('password').value;
    if (username === 'admin' && password === 'password') alert('Welcome ' + username + '!');
    else if (username === 'Display' && password === 'Smartmirror') alert('Welcome  ' + username + '!'); 
    else document.getElementById('error').textContent = 'Invalid username or password';
    setTimeout(function() { document.getElementById('error').textContent = ''; }, 3000);
});
